// +build darwin

package tcplisten

var newSocketCloexec = newSocketCloexecOld
